#!/usr/bin/env python3
"""
Generate all biomedical platform service files
"""

import os
import json

# Base directory
BASE_DIR = "/home/claude/biomedical-platform"

# Service configurations
SERVICES = {
    "ai-diagnostics": {
        "name": "AI Diagnostics",
        "icon": "🧠",
        "port_backend": 5001,
        "port_frontend": 3007,
        "color": "blue",
        "gradient": "from-blue-600 to-purple-600",
        "description": "ML-based Disease Prediction & Risk Assessment Platform",
        "tagline": "Advanced ML diagnostics with risk scoring and predictive analytics"
    },
    "medical-imaging": {
        "name": "Medical Imaging AI",
        "icon": "🔬",
        "port_backend": 5002,
        "port_frontend": 3002,
        "color": "indigo",
        "gradient": "from-indigo-600 to-blue-600",
        "description": "DICOM Processing with AI Inference & Grad-CAM Explainability",
        "tagline": "DICOM processing with AI inference and Grad-CAM explainability"
    },
    "biosensing": {
        "name": "Biosensing Technology",
        "icon": "📡",
        "port_backend": 5003,
        "port_frontend": 3003,
        "color": "teal",
        "gradient": "from-teal-600 to-green-600",
        "description": "Real-time Biosensor Monitoring with AWS IoT Core",
        "tagline": "Real-time monitoring with AWS IoT Core and WebSocket streaming"
    },
    "hipaa-compliance": {
        "name": "HIPAA Compliance",
        "icon": "🔐",
        "port_backend": 5004,
        "port_frontend": 3004,
        "color": "red",
        "gradient": "from-red-600 to-pink-600",
        "description": "Enterprise Security & Compliance Management Platform",
        "tagline": "AES-256-GCM encryption, audit logging, and breach tracking"
    },
    "biotensor-labs": {
        "name": "BioTensor Labs",
        "icon": "🧪",
        "port_backend": 5005,
        "port_frontend": 3005,
        "color": "purple",
        "gradient": "from-purple-600 to-indigo-600",
        "description": "MLOps Platform with MLflow Integration & Model Registry",
        "tagline": "MLOps platform with MLflow integration and model registry"
    }
}

def create_next_config(service_key):
    return """/** @type {import('next').NextConfig} */
const nextConfig = {}

module.exports = nextConfig
"""

def create_tsconfig_frontend():
    return """{
  "compilerOptions": {
    "target": "ES2020",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "forceConsistentCasingInFileNames": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true,
    "plugins": [
      {
        "name": "next"
      }
    ],
    "paths": {
      "@/*": ["./*"]
    }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
  "exclude": ["node_modules"]
}
"""

def create_next_env():
    return """/// <reference types="next" />
/// <reference types="next/image-types/global" />

// NOTE: This file should not be edited
// see https://nextjs.org/docs/basic-features/typescript for more information.
"""

# Create configuration files for all services
for service_key, config in SERVICES.items():
    frontend_dir = os.path.join(BASE_DIR, service_key, "frontend")
    
    # Create next.config.js
    with open(os.path.join(frontend_dir, "next.config.js"), "w") as f:
        f.write(create_next_config(service_key))
    
    # Create tsconfig.json
    with open(os.path.join(frontend_dir, "tsconfig.json"), "w") as f:
        f.write(create_tsconfig_frontend())
    
    # Create next-env.d.ts
    with open(os.path.join(frontend_dir, "next-env.d.ts"), "w") as f:
        f.write(create_next_env())

print("✅ Configuration files created for all services!")
