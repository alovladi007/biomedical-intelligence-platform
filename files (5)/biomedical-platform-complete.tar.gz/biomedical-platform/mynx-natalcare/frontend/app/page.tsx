'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Baby, Heart, Calendar, Activity, AlertCircle, TrendingUp, Users, CheckCircle, Phone, Mail, Clock, Bell, FileText, Stethoscope, User, BarChart } from 'lucide-react'

export default function Home() {
  const [activeTab, setActiveTab] = useState('overview')
  const [patients, setPatients] = useState<any[]>([])
  const [appointments, setAppointments] = useState<any[]>([])
  const [alerts, setAlerts] = useState<any[]>([])

  useEffect(() => {
    // Fetch data from backend
    fetch('http://localhost:5006/api/v1/patients')
      .then(res => res.json())
      .then(data => setPatients(data.patients || []))
      .catch(err => console.log('Backend not available'));

    fetch('http://localhost:5006/api/v1/appointments')
      .then(res => res.json())
      .then(data => setAppointments(data.appointments || []))
      .catch(err => console.log('Backend not available'));

    fetch('http://localhost:5006/api/v1/alerts')
      .then(res => res.json())
      .then(data => setAlerts(data.alerts || []))
      .catch(err => console.log('Backend not available'));
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-purple-50">
      {/* Top Bar */}
      <div className="bg-pink-600 text-white py-2.5">
        <div className="max-w-7xl mx-auto px-6 flex flex-wrap justify-between items-center text-sm">
          <div className="flex items-center gap-5">
            <div className="flex items-center gap-2">
              <Phone className="h-3.5 w-3.5" />
              <span>(800) 100-2000</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="h-3.5 w-3.5" />
              <span>care@mynxnatalcare.com</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="h-3.5 w-3.5" />
            <span>Maternal Care 24/7</span>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2.5">
              <div className="bg-gradient-to-br from-pink-500 to-purple-600 p-2 rounded-lg">
                <Baby className="h-6 w-6 text-white" strokeWidth={2.5} />
              </div>
              <div>
                <div className="text-lg font-bold text-gray-900">MYNX NatalCare</div>
                <div className="text-xs text-gray-500">Maternal Health Platform</div>
              </div>
            </div>

            <div className="flex items-center gap-6">
              <button className="text-sm font-medium text-gray-700 hover:text-pink-600">Dashboard</button>
              <button className="text-sm font-medium text-gray-700 hover:text-pink-600">Patients</button>
              <button className="text-sm font-medium text-gray-700 hover:text-pink-600">Appointments</button>
              <button className="relative">
                <Bell className="h-5 w-5 text-gray-700" />
                {alerts.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                    {alerts.length}
                  </span>
                )}
              </button>
              <button className="px-5 py-2 bg-pink-600 hover:bg-pink-700 text-white text-sm font-semibold rounded-lg transition shadow-md">
                New Patient
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Stats */}
      <section className="py-8 px-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Maternal Care Dashboard</h1>
          
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-pink-500">
              <div className="flex items-center justify-between mb-3">
                <div className="bg-pink-100 p-3 rounded-lg">
                  <Users className="h-6 w-6 text-pink-600" />
                </div>
                <span className="text-xs font-semibold text-green-600 bg-green-100 px-2 py-1 rounded">+12%</span>
              </div>
              <div className="text-2xl font-bold text-gray-900">{patients.length}</div>
              <div className="text-sm text-gray-600">Active Patients</div>
            </div>

            <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-purple-500">
              <div className="flex items-center justify-between mb-3">
                <div className="bg-purple-100 p-3 rounded-lg">
                  <Calendar className="h-6 w-6 text-purple-600" />
                </div>
                <span className="text-xs font-semibold text-blue-600 bg-blue-100 px-2 py-1 rounded">Today</span>
              </div>
              <div className="text-2xl font-bold text-gray-900">{appointments.length}</div>
              <div className="text-sm text-gray-600">Appointments</div>
            </div>

            <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-orange-500">
              <div className="flex items-center justify-between mb-3">
                <div className="bg-orange-100 p-3 rounded-lg">
                  <AlertCircle className="h-6 w-6 text-orange-600" />
                </div>
                <span className="text-xs font-semibold text-red-600 bg-red-100 px-2 py-1 rounded">Urgent</span>
              </div>
              <div className="text-2xl font-bold text-gray-900">{alerts.length}</div>
              <div className="text-sm text-gray-600">Active Alerts</div>
            </div>

            <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-green-500">
              <div className="flex items-center justify-between mb-3">
                <div className="bg-green-100 p-3 rounded-lg">
                  <TrendingUp className="h-6 w-6 text-green-600" />
                </div>
                <span className="text-xs font-semibold text-green-600 bg-green-100 px-2 py-1 rounded">98%</span>
              </div>
              <div className="text-2xl font-bold text-gray-900">Excellent</div>
              <div className="text-sm text-gray-600">Care Quality</div>
            </div>
          </div>

          {/* Main Content */}
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Recent Patients */}
            <div className="lg:col-span-2 bg-white rounded-xl shadow-md p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-gray-900">Recent Patients</h2>
                <button className="text-sm text-pink-600 hover:text-pink-700 font-medium">View All</button>
              </div>
              
              <div className="space-y-3">
                {patients.slice(0, 5).map((patient) => (
                  <div key={patient.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition">
                    <div className="flex items-center gap-3">
                      <div className="bg-pink-100 p-2 rounded-full">
                        <User className="h-5 w-5 text-pink-600" />
                      </div>
                      <div>
                        <div className="font-semibold text-gray-900">{patient.name}</div>
                        <div className="text-xs text-gray-600">Week {patient.gestationalWeek} • Due: {patient.dueDate}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-xs font-semibold px-2 py-1 rounded ${
                        patient.riskLevel === 'low' ? 'bg-green-100 text-green-700' :
                        patient.riskLevel === 'moderate' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-red-100 text-red-700'
                      }`}>
                        {patient.riskLevel}
                      </span>
                      <button className="text-pink-600 hover:text-pink-700">
                        <FileText className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Alerts & Appointments */}
            <div className="space-y-6">
              {/* Active Alerts */}
              <div className="bg-white rounded-xl shadow-md p-6">
                <div className="flex items-center gap-2 mb-4">
                  <AlertCircle className="h-5 w-5 text-orange-600" />
                  <h2 className="text-lg font-bold text-gray-900">Active Alerts</h2>
                </div>
                
                <div className="space-y-3">
                  {alerts.slice(0, 3).map((alert) => (
                    <div key={alert.id} className={`p-3 rounded-lg border-l-4 ${
                      alert.severity === 'high' ? 'bg-red-50 border-red-500' :
                      alert.severity === 'medium' ? 'bg-orange-50 border-orange-500' :
                      'bg-yellow-50 border-yellow-500'
                    }`}>
                      <div className="text-sm font-semibold text-gray-900">{alert.message}</div>
                      <div className="text-xs text-gray-600 mt-1">{alert.patientName}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Today's Appointments */}
              <div className="bg-white rounded-xl shadow-md p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Calendar className="h-5 w-5 text-purple-600" />
                  <h2 className="text-lg font-bold text-gray-900">Today's Schedule</h2>
                </div>
                
                <div className="space-y-3">
                  {appointments.slice(0, 3).map((apt) => (
                    <div key={apt.id} className="p-3 bg-purple-50 rounded-lg">
                      <div className="flex items-center justify-between mb-1">
                        <div className="text-sm font-semibold text-gray-900">{apt.time}</div>
                        <span className="text-xs bg-purple-200 text-purple-700 px-2 py-0.5 rounded">{apt.type}</span>
                      </div>
                      <div className="text-xs text-gray-600">{apt.patientName}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Vital Signs Monitoring */}
          <div className="mt-6 bg-white rounded-xl shadow-md p-6">
            <div className="flex items-center gap-2 mb-4">
              <Activity className="h-5 w-5 text-green-600" />
              <h2 className="text-xl font-bold text-gray-900">Vital Signs Monitoring</h2>
            </div>
            
            <div className="grid md:grid-cols-4 gap-4">
              {[
                { label: 'Blood Pressure', value: '118/76', unit: 'mmHg', status: 'normal', icon: Heart },
                { label: 'Heart Rate', value: '72', unit: 'bpm', status: 'normal', icon: Activity },
                { label: 'Weight Gain', value: '+2.1', unit: 'kg', status: 'good', icon: TrendingUp },
                { label: 'Fetal Heart', value: '145', unit: 'bpm', status: 'normal', icon: Stethoscope }
              ].map((vital, idx) => (
                <div key={idx} className="p-4 bg-gradient-to-br from-gray-50 to-white rounded-lg border border-gray-200">
                  <div className="flex items-center justify-between mb-2">
                    <vital.icon className="h-5 w-5 text-gray-600" />
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  </div>
                  <div className="text-2xl font-bold text-gray-900">{vital.value}</div>
                  <div className="text-xs text-gray-600">{vital.label}</div>
                  <div className="text-xs text-gray-500">{vital.unit}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 mt-12">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <div className="flex items-center justify-center gap-2 mb-3">
            <Baby className="h-6 w-6" />
            <span className="font-bold text-lg">MYNX NatalCare</span>
          </div>
          <p className="text-sm text-gray-400 mb-2">Comprehensive Maternal Health Monitoring</p>
          <div className="text-xs text-gray-500">© 2025 M.Y. Engineering. All rights reserved.</div>
        </div>
      </footer>
    </div>
  )
}
