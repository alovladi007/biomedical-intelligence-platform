#!/usr/bin/env python3
"""
Comprehensive BioMedical Platform File Generator
Creates all missing files for production-ready deployment
"""

import os
import json

# Service configurations
SERVICES = {
    'ai-diagnostics': {
        'name': 'AI Diagnostics',
        'backend_port': 5001,
        'frontend_port': 3007,
        'description': 'ML-based Medical Diagnostics Platform',
        'icon': '🧠'
    },
    'medical-imaging': {
        'name': 'Medical Imaging AI',
        'backend_port': 5002,
        'frontend_port': 3002,
        'description': 'DICOM Processing and AI Inference',
        'icon': '🔬'
    },
    'biosensing': {
        'name': 'Biosensing Technology',
        'backend_port': 5003,
        'frontend_port': 3003,
        'description': 'Real-time Health Monitoring',
        'icon': '📡'
    },
    'hipaa-compliance': {
        'name': 'HIPAA Compliance',
        'backend_port': 5004,
        'frontend_port': 3004,
        'description': 'Security and Compliance Management',
        'icon': '🔒'
    },
    'biotensor-labs': {
        'name': 'BioTensor Labs',
        'backend_port': 5005,
        'frontend_port': 3005,
        'description': 'MLOps and Model Management',
        'icon': '🧪'
    },
    'mynx-natalcare': {
        'name': 'MYNX NatalCare',
        'backend_port': 5006,
        'frontend_port': 3006,
        'description': 'Maternal Health Monitoring',
        'icon': '🤰'
    }
}

def create_backend_dockerfile(service_key, config):
    """Create Dockerfile for backend service"""
    content = f"""FROM node:18-alpine

WORKDIR /app

# Install dependencies
COPY package*.json ./
RUN npm ci --only=production

# Copy source
COPY . .

# Build TypeScript
RUN npm run build

# Expose port
EXPOSE {config['backend_port']}

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \\
  CMD node -e "require('http').get('http://localhost:{config['backend_port']}/health', (r) => {{ process.exit(r.statusCode === 200 ? 0 : 1); }});"

# Start server
CMD ["npm", "start"]
"""
    
    path = f"{service_key}/backend/Dockerfile"
    with open(path, 'w') as f:
        f.write(content)
    print(f"✓ Created {path}")

def create_frontend_dockerfile(service_key, config):
    """Create Dockerfile for frontend service"""
    content = f"""FROM node:18-alpine AS builder

WORKDIR /app

# Install dependencies
COPY package*.json ./
RUN npm ci

# Copy source and build
COPY . .
RUN npm run build

# Production image
FROM node:18-alpine

WORKDIR /app

# Copy built assets
COPY --from=builder /app/.next ./.next
COPY --from=builder /app/node_modules ./node_modules
COPY --from=builder /app/package*.json ./
COPY --from=builder /app/public ./public

# Expose port
EXPOSE {config['frontend_port']}

# Start Next.js
CMD ["npm", "start"]
"""
    
    path = f"{service_key}/frontend/Dockerfile"
    with open(path, 'w') as f:
        f.write(content)
    print(f"✓ Created {path}")

def create_backend_env(service_key, config):
    """Create .env file for backend"""
    content = f"""# {config['name']} Backend Configuration
PORT={config['backend_port']}
NODE_ENV=development
CORS_ORIGINS=http://localhost:{config['frontend_port']},http://localhost:8080
DEMO_MODE=true

# Database (when ready)
# DATABASE_URL=postgresql://user:password@localhost:5432/biomedical
# REDIS_URL=redis://localhost:6379

# Security
# JWT_SECRET=your-secret-key-change-in-production
# ENCRYPTION_KEY=your-encryption-key-change-in-production

# AWS (when ready)
# AWS_REGION=us-east-1
# AWS_ACCESS_KEY_ID=your-access-key
# AWS_SECRET_ACCESS_KEY=your-secret-key
# S3_BUCKET=biomedical-platform

# Logging
LOG_LEVEL=info
"""
    
    path = f"{service_key}/backend/.env"
    if not os.path.exists(path):
        with open(path, 'w') as f:
            f.write(content)
        print(f"✓ Created {path}")

def create_frontend_env(service_key, config):
    """Create .env.local file for frontend"""
    content = f"""# {config['name']} Frontend Configuration
NEXT_PUBLIC_API_URL=http://localhost:{config['backend_port']}
NEXT_PUBLIC_SERVICE_NAME={config['name']}
NEXT_PUBLIC_SERVICE_DESCRIPTION={config['description']}
"""
    
    path = f"{service_key}/frontend/.env.local"
    with open(path, 'w') as f:
        f.write(content)
    print(f"✓ Created {path}")

def create_postcss_config(service_key):
    """Create PostCSS configuration"""
    content = """module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
"""
    
    path = f"{service_key}/frontend/postcss.config.js"
    if not os.path.exists(path):
        with open(path, 'w') as f:
            f.write(content)
        print(f"✓ Created {path}")

def create_next_config(service_key, config):
    """Create Next.js configuration"""
    content = f"""/** @type {{import('next').NextConfig}} */
const nextConfig = {{
  reactStrictMode: true,
  swcMinify: true,
  env: {{
    NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL,
  }},
  async rewrites() {{
    return [
      {{
        source: '/api/:path*',
        destination: 'http://localhost:{config['backend_port']}/api/:path*',
      }},
    ]
  }},
}}

module.exports = nextConfig
"""
    
    path = f"{service_key}/frontend/next.config.js"
    if not os.path.exists(path):
        with open(path, 'w') as f:
            f.write(content)
        print(f"✓ Created {path}")

def create_gitignore(service_key):
    """Create .gitignore files"""
    backend_ignore = """node_modules/
dist/
build/
.env
.env.local
.env.*.local
*.log
logs/
.DS_Store
"""
    
    frontend_ignore = """.next/
out/
node_modules/
.env
.env.local
.env.*.local
*.log
.DS_Store
"""
    
    # Backend .gitignore
    backend_path = f"{service_key}/backend/.gitignore"
    if not os.path.exists(backend_path):
        with open(backend_path, 'w') as f:
            f.write(backend_ignore)
        print(f"✓ Created {backend_path}")
    
    # Frontend .gitignore
    frontend_path = f"{service_key}/frontend/.gitignore"
    if not os.path.exists(frontend_path):
        with open(frontend_path, 'w') as f:
            f.write(frontend_ignore)
        print(f"✓ Created {frontend_path}")

# Main execution
print("🏥 Creating Comprehensive BioMedical Platform Files")
print("=" * 60)

for service_key, config in SERVICES.items():
    print(f"\n{config['icon']} Processing {config['name']}...")
    
    # Create backend files
    create_backend_dockerfile(service_key, config)
    create_backend_env(service_key, config)
    
    # Create frontend files
    create_frontend_dockerfile(service_key, config)
    create_frontend_env(service_key, config)
    create_postcss_config(service_key)
    create_next_config(service_key, config)
    create_gitignore(service_key)

print("\n" + "=" * 60)
print("✅ All configuration files created successfully!")
print("\nNext steps:")
print("1. Review and customize .env files with your settings")
print("2. Run ./install-all.sh to install dependencies")
print("3. Run ./start-all.sh to start all services")

