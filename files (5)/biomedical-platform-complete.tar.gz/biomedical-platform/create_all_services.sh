#!/bin/bash

# This script will create all the remaining service files efficiently

# Create all necessary directories
for service in ai-diagnostics medical-imaging biosensing hipaa-compliance biotensor-labs; do
    mkdir -p $service/frontend/app/dashboard
    mkdir -p $service/backend/.env-example
done

echo "Directories created successfully!"
