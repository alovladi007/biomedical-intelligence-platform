#!/usr/bin/env python3
"""
BioMedical Platform - Complete Service Generator
Generates all 6 microservices with backend and frontend
"""

import os
import json

SERVICES = {
    "ai-diagnostics": {
        "name": "AI Diagnostics",
        "desc": "ML-based Medical Diagnostics Platform",
        "backend_port": 5001,
        "frontend_port": 3007,
        "icon": "🧠",
        "color": "blue",
        "features": [
            "ML-based disease prediction",
            "Risk scoring and assessment",
            "Predictive analytics",
            "Clinical decision support"
        ]
    },
    "medical-imaging": {
        "name": "Medical Imaging AI",
        "desc": "DICOM Processing and AI Inference Platform",
        "backend_port": 5002,
        "frontend_port": 3002,
        "icon": "🔬",
        "color": "indigo",
        "features": [
            "DICOM image processing",
            "AI-powered diagnosis",
            "Grad-CAM explainability",
            "Automated triage"
        ]
    },
    "biosensing": {
        "name": "Biosensing Technology",
        "desc": "Real-time Health Monitoring Platform",
        "backend_port": 5003,
        "frontend_port": 3003,
        "icon": "📡",
        "color": "teal",
        "features": [
            "Real-time sensor monitoring",
            "AWS IoT Core integration",
            "WebSocket streaming",
            "Anomaly detection"
        ]
    },
    "hipaa-compliance": {
        "name": "HIPAA Compliance",
        "desc": "Security and Compliance Management",
        "backend_port": 5004,
        "frontend_port": 3004,
        "icon": "🔐",
        "color": "red",
        "features": [
            "AES-256-GCM encryption",
            "Audit logging",
            "Breach tracking",
            "Compliance reporting"
        ]
    },
    "biotensor-labs": {
        "name": "BioTensor Labs",
        "desc": "MLOps and Model Management Platform",
        "backend_port": 5005,
        "frontend_port": 3005,
        "icon": "🧪",
        "color": "purple",
        "features": [
            "MLflow integration",
            "Model registry",
            "Experiment tracking",
            "Model deployment"
        ]
    },
    "mynx-natalcare": {
        "name": "MYNX NatalCare",
        "desc": "Maternal Health Monitoring Platform",
        "backend_port": 5006,
        "frontend_port": 3006,
        "icon": "🤰",
        "color": "pink",
        "features": [
            "Prenatal care tracking",
            "Appointment management",
            "Vital signs monitoring",
            "Risk assessment"
        ]
    }
}

def create_backend_structure(service_key, config):
    """Create backend structure for a service"""
    base_path = f"{service_key}/backend"
    
    # Create directories
    os.makedirs(f"{base_path}/src", exist_ok=True)
    
    # package.json
    package_json = {
        "name": f"@biomedical/{service_key}-backend",
        "version": "1.0.0",
        "description": f"{config['name']} - {config['desc']} Backend",
        "main": "dist/index.js",
        "scripts": {
            "dev": "nodemon --exec ts-node src/index.ts",
            "build": "tsc",
            "start": "node dist/index.js",
            "lint": "eslint src --ext .ts",
            "test": "jest"
        },
        "keywords": [service_key, "healthcare", "biomedical"],
        "author": "M.Y. Engineering and Technologies",
        "license": "MIT",
        "dependencies": {
            "express": "^4.18.2",
            "cors": "^2.8.5",
            "dotenv": "^16.3.1",
            "helmet": "^7.1.0",
            "morgan": "^1.10.0",
            "compression": "^1.7.4",
            "express-rate-limit": "^7.1.5",
            "winston": "^3.11.0"
        },
        "devDependencies": {
            "@types/express": "^4.17.21",
            "@types/cors": "^2.8.17",
            "@types/morgan": "^1.9.9",
            "@types/compression": "^1.7.5",
            "@types/node": "^20.10.4",
            "typescript": "^5.3.3",
            "ts-node": "^10.9.2",
            "nodemon": "^3.0.2",
            "@typescript-eslint/eslint-plugin": "^6.14.0",
            "@typescript-eslint/parser": "^6.14.0",
            "eslint": "^8.55.0"
        }
    }
    
    with open(f"{base_path}/package.json", 'w') as f:
        json.dump(package_json, f, indent=2)
    
    # tsconfig.json
    tsconfig = {
        "compilerOptions": {
            "target": "ES2020",
            "module": "commonjs",
            "lib": ["ES2020"],
            "outDir": "./dist",
            "rootDir": "./src",
            "strict": True,
            "esModuleInterop": True,
            "skipLibCheck": True,
            "forceConsistentCasingInFileNames": True,
            "resolveJsonModule": True,
            "declaration": True,
            "sourceMap": True,
            "moduleResolution": "node"
        },
        "include": ["src/**/*"],
        "exclude": ["node_modules", "dist"]
    }
    
    with open(f"{base_path}/tsconfig.json", 'w') as f:
        json.dump(tsconfig, f, indent=2)
    
    # .env
    env_content = f"""PORT={config['backend_port']}
NODE_ENV=development
CORS_ORIGINS=http://localhost:{config['frontend_port']}
DEMO_MODE=true
"""
    
    with open(f"{base_path}/.env", 'w') as f:
        f.write(env_content)
    
    # src/index.ts - will be created separately with full implementation
    
    print(f"   ✓ Backend structure created for {service_key}")

def create_frontend_structure(service_key, config):
    """Create frontend structure for a service"""
    base_path = f"{service_key}/frontend"
    
    # Create directories
    os.makedirs(f"{base_path}/app", exist_ok=True)
    os.makedirs(f"{base_path}/public", exist_ok=True)
    
    # package.json
    package_json = {
        "name": f"@biomedical/{service_key}-frontend",
        "version": "1.0.0",
        "private": True,
        "scripts": {
            "dev": f"next dev -p {config['frontend_port']}",
            "build": "next build",
            "start": f"next start -p {config['frontend_port']}",
            "lint": "next lint"
        },
        "dependencies": {
            "lucide-react": "^0.545.0",
            "next": "14.0.4",
            "react": "^18.2.0",
            "react-dom": "^18.2.0",
            "typescript": "^5.3.3"
        },
        "devDependencies": {
            "@types/node": "^20.10.4",
            "@types/react": "^18.2.42",
            "@types/react-dom": "^18.2.17",
            "autoprefixer": "^10.4.16",
            "eslint": "^8.55.0",
            "eslint-config-next": "14.0.4",
            "postcss": "^8.4.32",
            "tailwindcss": "^3.3.6"
        }
    }
    
    with open(f"{base_path}/package.json", 'w') as f:
        json.dump(package_json, f, indent=2)
    
    # tsconfig.json
    tsconfig = {
        "compilerOptions": {
            "target": "ES2020",
            "lib": ["dom", "dom.iterable", "esnext"],
            "allowJs": True,
            "skipLibCheck": True,
            "strict": True,
            "forceConsistentCasingInFileNames": True,
            "noEmit": True,
            "esModuleInterop": True,
            "module": "esnext",
            "moduleResolution": "bundler",
            "resolveJsonModule": True,
            "isolatedModules": True,
            "jsx": "preserve",
            "incremental": True,
            "plugins": [{"name": "next"}],
            "paths": {"@/*": ["./*"]}
        },
        "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
        "exclude": ["node_modules"]
    }
    
    with open(f"{base_path}/tsconfig.json", 'w') as f:
        json.dump(tsconfig, f, indent=2)
    
    # next.config.js
    next_config = """/** @type {import('next').NextConfig} */
const nextConfig = {}

module.exports = nextConfig
"""
    
    with open(f"{base_path}/next.config.js", 'w') as f:
        f.write(next_config)
    
    # tailwind.config.ts
    tailwind_config = """import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
export default config
"""
    
    with open(f"{base_path}/tailwind.config.ts", 'w') as f:
        f.write(tailwind_config)
    
    # postcss.config.js
    postcss_config = """module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
"""
    
    with open(f"{base_path}/postcss.config.js", 'w') as f:
        f.write(postcss_config)
    
    # next-env.d.ts
    next_env = """/// <reference types="next" />
/// <reference types="next/image-types/global" />

// NOTE: This file should not be edited
// see https://nextjs.org/docs/basic-features/typescript for more information.
"""
    
    with open(f"{base_path}/next-env.d.ts", 'w') as f:
        f.write(next_env)
    
    # app/globals.css
    globals_css = """@tailwind base;
@tailwind components;
@tailwind utilities;
"""
    
    with open(f"{base_path}/app/globals.css", 'w') as f:
        f.write(globals_css)
    
    print(f"   ✓ Frontend structure created for {service_key}")

def main():
    print("🏥 BioMedical Platform - Service Generator")
    print("=" * 50)
    print()
    
    for service_key, config in SERVICES.items():
        print(f"📦 Creating {config['name']}...")
        create_backend_structure(service_key, config)
        create_frontend_structure(service_key, config)
        print()
    
    print("✅ All service structures created successfully!")
    print()
    print("Next: Creating implementation files...")

if __name__ == "__main__":
    main()
