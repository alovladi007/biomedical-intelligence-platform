#!/bin/bash

echo "🏥 Setting up BioMedical Intelligence Platform"
echo "================================================"
echo ""

# Create directory structure for all 6 services
SERVICES=(
  "ai-diagnostics:5001:3007"
  "medical-imaging:5002:3002"
  "biosensing:5003:3003"
  "hipaa-compliance:5004:3004"
  "biotensor-labs:5005:3005"
  "mynx-natalcare:5006:3006"
)

for service_info in "${SERVICES[@]}"; do
  IFS=':' read -r service backend_port frontend_port <<< "$service_info"
  
  echo "📦 Creating $service structure..."
  
  # Create directories
  mkdir -p "$service/backend/src"
  mkdir -p "$service/frontend/app"
  mkdir -p "$service/frontend/public"
  
  echo "   ✓ Directories created"
done

echo ""
echo "✅ Directory structure created successfully!"
echo ""
echo "Next steps:"
echo "1. Install dependencies: ./install-all.sh"
echo "2. Start all services: ./start-all.sh"
